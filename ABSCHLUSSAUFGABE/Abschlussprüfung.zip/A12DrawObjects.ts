namespace rodelbahnA12 {

    export class DrawObjects {
        xPos: number;
        yPos: number;
        onlysledge: boolean;
         mDown: boolean;
        
        constructor() {
            
        }
        

        draw(): void {

        }

        move(): void {

        }

    }




}