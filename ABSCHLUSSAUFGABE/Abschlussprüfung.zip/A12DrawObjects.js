var rodelbahnA12;
(function (rodelbahnA12) {
    class DrawObjects {
        constructor() {
        }
        draw() {
        }
        move() {
        }
    }
    rodelbahnA12.DrawObjects = DrawObjects;
})(rodelbahnA12 || (rodelbahnA12 = {}));
//# sourceMappingURL=A12DrawObjects.js.map